load('libs.js');
load('config.js');

function execute(url) {
    Console.log("[PAGE] === BẮT ĐẦU XỬ LÝ (BROWSER MODE) ===");
    Console.log("[PAGE] URL đầu vào: " + url);

    url = url.replace("http://", "https://");
    
    // 1. Chuyển đổi URL sang indexlist
    let indexUrl = url.replace(/\/book\//, "/indexlist/");
    Console.log("[PAGE] URL sau khi convert: " + indexUrl);
    
    // 2. SỬ DỤNG BROWSER THAY VÌ FETCH
    let browser = Engine.newBrowser();
    
    // Set User-Agent giống trình duyệt thật để Cloudflare tin tưởng
    browser.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
    
    // Launch trang web với timeout dài (20s) để Cloudflare kịp chạy xác minh
    // Trình duyệt sẽ tự động xử lý redirect nếu Cloudflare refresh trang
    browser.launch(indexUrl, 20000); 
    
    // Lấy HTML sau khi trình duyệt đã tải xong (và vượt qua Cloudflare)
    let doc = browser.html();
    
    // Đóng browser để giải phóng bộ nhớ
    browser.close();
    
    if (doc) {
        // Kiểm tra xem có bị dính trang Cloudflare không (bằng cách check title hoặc nội dung)
        let htmlContent = doc.html();
        if (htmlContent.indexOf("Cloudflare") !== -1 && htmlContent.indexOf("Verify") !== -1) {
             Console.log("[PAGE] CẢNH BÁO: Vẫn bị dính Cloudflare!");
        }

        let pageList = [];
        
        // Selector options (Logic cũ của bạn)
        let options = doc.select("#indexselect-top option");
        Console.log("[PAGE] Số lượng option tìm thấy: " + options.size());

        options.forEach(e => {
            let value = e.attr("value");
            if (value) {
                if (value.startsWith("/")) {
                    value = "https://69shuba.tw" + value;
                }
                pageList.push(value);
            }
        });

        // Nếu không tìm thấy phân trang (truyện ngắn hoặc chỉ có 1 trang)
        if (pageList.length === 0) {
            Console.log("[PAGE] Không thấy phân trang, dùng chính URL index.");
            pageList.push(indexUrl);
        }

        Console.log("[PAGE] Kết quả trả về " + pageList.length + " trang.");
        return Response.success(pageList);
    } 
    
    Console.log("[PAGE] Browser không trả về dữ liệu.");
    return null;
}